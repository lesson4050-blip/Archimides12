# WebSocket handler for Archimedes
