import logging
from typing import List, Dict, Any, Optional
import ollama
from backend.config import settings

logger = logging.getLogger(__name__)

class OllamaClient:
    def __init__(self):
        self.client = ollama.AsyncClient(host=settings.OLLAMA_BASE_URL)
        self.model = "hf.co/bartowski/Qwen2.5-32B-Instruct-GGUF:Q4_K_M"

    async def generate_with_tools(self, messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        # Inject tool descriptions into the system prompt if tools are provided
        if tools:
            tool_descriptions = "\n".join([
                f"- {t['function']['name']}: {t['function']['description']}. Params: {t['function']['parameters']}"
                for t in tools
            ])
            system_injection = f"\n\nYou have access to the following tools. To use them, output only a JSON object like: {{\"tool_call\": {{\"name\": \"tool_name\", \"params\": {{...}}}}}}.\nTools:\n{tool_descriptions}"
            
            # Find the system message and append tool descriptions
            found_system = False
            for msg in messages:
                if msg["role"] == "system":
                    msg["content"] += system_injection
                    found_system = True
                    break
            if not found_system:
                messages.insert(0, {"role": "system", "content": system_injection})

        try:
            response = await self.client.chat(
                model=self.model,
                messages=messages
            )
            
            content = response.message.content
            thought = ""
            text = content
            tool_call = None
            
            # Try to extract <thought> blocks (DeepSeek R1 does this)
            if "<thought>" in content and "</thought>" in content:
                thought = content.split("<thought>")[1].split("</thought>")[0].strip()
                text = content.split("</thought>")[1].strip()
            
            # Try to extract tool call from the text if it's injected
            import json
            try:
                # Look for ANY JSON block
                if "{" in text and "}" in text:
                    start = text.find("{")
                    end = text.rfind("}") + 1
                    json_str = text[start:end]
                    data = json.loads(json_str)
                    
                    # Case 1: Wrapped in "tool_call"
                    if "tool_call" in data:
                        tool_call = data["tool_call"]
                        text = text[:start].strip()
                    # Case 2: Direct "name" and "params" (common in some model outputs)
                    elif "name" in data and ("params" in data or "arguments" in data):
                        tool_call = {
                            "name": data["name"],
                            "params": data.get("params") or data.get("arguments")
                        }
                        text = text[:start].strip()
            except:
                pass
                    
            return {
                "model_used": "ollama",
                "thought": thought,
                "tool_call": tool_call,
                "text": text,
                "tokens_used": 0 # Ollama SDK return for usage is different
            }

        except Exception as e:
            logger.error(f"Ollama API error: {e}")
            raise e
