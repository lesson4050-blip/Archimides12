import logging
from typing import List, Dict, Any, Optional
from backend.models.groq_client import GroqClient, RateLimitExceeded as GroqRateLimit
from backend.models.gemini_client import GeminiClient, RateLimitExceeded as GeminiRateLimit
from backend.models.ollama_client import OllamaClient

logger = logging.getLogger(__name__)

class AllModelsExhausted(Exception):
    pass

class ModelRouter:
    # Tasks that require Gemini's quality (long context, planning, research)
    GEMINI_FIRST_TASKS = {"plan", "browser", "search", "result", "summarize"}

    def __init__(self):
        self.groq = GroqClient()
        self.gemini = GeminiClient()
        self.ollama = OllamaClient()

    async def generate(self, messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]] = None, task_hint: str = "default") -> Dict[str, Any]:
        if task_hint in self.GEMINI_FIRST_TASKS:
            order = [self.ollama, self.gemini, self.groq]       # Ollama → Gemini → Groq
        else:
            order = [self.ollama, self.groq, self.gemini]       # Ollama → Groq → Gemini

        errors = []
        for client in order:
            try:
                # We need to make sure tool format is normalized? 
                # Groq and Gemini clients should handle their respective formats.
                return await client.generate_with_tools(messages, tools)
            except (GroqRateLimit, GeminiRateLimit) as e:
                logger.warning(f"Model tier {client.__class__.__name__} failed with rate limit. Trying next...")
                errors.append(str(e))
                continue
            except Exception as e:
                logger.error(f"Model tier {client.__class__.__name__} failed with error: {e}")
                errors.append(str(e))
                continue
                
        raise AllModelsExhausted(f"All model tiers failed: {', '.join(errors)}")
